﻿namespace CyberEvidencePortal.Models
{
    public enum UserRole
    {
        Admin = 1,
        User = 2
    }
}

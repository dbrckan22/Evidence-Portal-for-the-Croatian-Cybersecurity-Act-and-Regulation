﻿namespace CyberEvidencePortal.DTOs
{
    public class CreateOrganizationDto
    {
        public string Name { get; set; }
        public string Oib { get; set; }
        public string Email { get; set; }
    }
}
